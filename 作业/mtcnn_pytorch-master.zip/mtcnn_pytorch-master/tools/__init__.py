from .test_detect import MtcnnDetector

__all__ = [
    'MtcnnDetector'
]